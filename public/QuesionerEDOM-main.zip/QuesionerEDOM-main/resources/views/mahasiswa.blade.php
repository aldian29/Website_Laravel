@extends("appearance")

@section("title")
@endsection

@section("body")
@endsection

@section("isi")
@endsection

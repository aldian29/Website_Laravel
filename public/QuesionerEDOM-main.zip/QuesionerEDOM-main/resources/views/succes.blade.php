@extends("appearance")

@section("title")
@endsection

@section("body")
@endsection

@section("isi")
<div class="card">

</div>
@endsection
